$(document).ready(function()
{

	//It will only accept the decimal values
	$('.decimal').keyup(function()
	{
	  var val = $(this).val();
	  if(isNaN(val)){
	       val = val.replace(/[^0-9\.]/g,'');
	       if(val.split('.').length>2) 
	           val= val.replace(/\.+$/,"");
	  }
	  $(this).val(val); 
	});

	//It will only accept the numbers not letters
	$(".digits").keypress(function (e) 
	{
	    //if the letter is not digit then display error and don't type anything
	    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
	        return false;
	    }
    });


	// Add to Favouite
	$(document).on('click', '.fav_add', function() {
	    var propertyID = $(this).attr('data-propertyid');

	    $.ajax({
	        headers: {
	            'X-CSRF-Token': $('input[name="_token"]').val()
	        },
	        type: 'POST',
	        dataType: 'JSON',
	        url: SITE_URL + '/property/add-favorite/' + propertyID,
	        beforeSend: function() {
	            $('.fav_add').attr('disabled', true);
	            $('#fav_' + propertyID).html('<i style="font-size:30px;color:#1f4e78;text-align: center;" class="fa fa-spinner fa-pulse"></i><span class="bigger-110"></span>');
	        },
	        success: function(data) 
	        {
	            if ($.trim(data.status) == 'success') 
	            {
	                $('#fav_' + propertyID).html('<a href="javascript:void(0);" data-id="' + data.fav_id + '" data-propertyID="' + propertyID + '" title="Remove" class="fav-new-css fav_remove btn-favorite"><span><i class="fa fa-heart" aria-hidden="true"></i></span></a>');
	                $('.fav_add').attr('disabled', false);
	                swal('success','Property successfully added to your favourite list','success');
	            } else {
	                swal('warning','Unable to add property to your favourite list','warning');
	            }

	        }
	    });
	    return false;
	});


	/* unfavorite */
	$(document).on('click', '.fav_remove', function() {
	    var propertyId = $(this).attr('data-propertyid');
	    var favId = $(this).attr('data-id');
	    
	    swal({
	            title: 'Are you sure ?',
	            text: 'Do you want remove this record',
	            type: "warning",
	            showCancelButton: true,
	            confirmButtonColor: "#5b9bd5",
	            confirmButtonText: 'Remove',
	            cancelButtonText: 'Cancel',
	        },
	        function() {
	            $.ajax({
	                headers: {
	                    'X-CSRF-Token': $('input[name="_token"]').val()
	                },
	                type: 'POST',
	                dataType: 'JSON',
	                url: SITE_URL + '/property/remove-favorite/' + favId,
	                beforeSend: function() {
	                    $('.fav_remove').attr('disabled', true);
	                    $('#fav_' + propertyId).html('<i style="font-size:30px;color:#1f4e78;text-align: center;" class="fa fa-spinner fa-pulse"></i><span class="bigger-110"></span>');
	                },
	                success: function(data) {
	                    if ($.trim(data.status) == 'success') {
	                        $('#fav_' + propertyId).html('<a href="javascript:void(0);" class="fav-new-css btn-favorite fav_add"  title="Favourite" data-propertyid="' + propertyId + '"><span><i class="fa fa-heart-o" aria-hidden="true"></i></span></a>');
	                        $('.fav_remove').attr('disabled', false);
	                        swal('success','Property successfully removed from your favourite list','success');
	                    } else {
	                        swal('warning','Unable to remove property from your favourite list','warning');
	                    }

	                }
	            });
	            return true;
	        });
    	return false;
	});

	//set session ajax call
    $(document).on("click",".save-session", function(){
      var csrf_token = $("input[name=_token]").val();
      
      var redirect_to      = window.location.href;     

      console.log(redirect_to);

      	$.ajax({
            headers: {'X-CSRF-TOKEN': csrf_token},
            url:SITE_URL+"/save_session",
            type:'POST',
            data:{redirect_to},
            dataType:'json',
            success:function(response)
            {
              window.location.href = SITE_URL+'/login'; 
            }
       });                        
    });
    
});
